import { test, expect } from 'vitest'
import { toRawType } from '../src/wenyejie'

test('toRawType object', () => {
  expect(toRawType({})).toBe('object')
  expect(toRawType('')).toBe('string')
})