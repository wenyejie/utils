/**
 *
 */
export const hasOwnProperty = Object.prototype.hasOwnProperty
export default hasOwnProperty
