export const isDefined = value => value !== undefined && value !== null

export default isDefined
