// 首字母大写
export const capitalize = str => {
  return str.charAt(0).toUpperCase() + str.slice(1)
}

export default capitalize
