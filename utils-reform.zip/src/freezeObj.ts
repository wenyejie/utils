import emptyObject from './emptyObject'

// 被冻结的空对象
export const freezeObj = emptyObject
export default freezeObj
