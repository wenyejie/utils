// 判断是否为整数
export const isInteger = Number.isInteger

export default isInteger
