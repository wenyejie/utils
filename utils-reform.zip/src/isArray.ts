// 判断一个对象是否为数组
export const isArray = Array.isArray

export default isArray
