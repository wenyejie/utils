/**
 * 判断一个值是否为null
 * @param value
 */
export const isNull = (value: unknown) => value === null

export default isNull
