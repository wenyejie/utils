/**
 * 空函数
 */
export const noop = function() {}
export default noop
