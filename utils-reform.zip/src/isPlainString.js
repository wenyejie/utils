export const isPlainString = obj => typeof obj === 'string'

export default isPlainString
