/**
 * 判断是否为数字
 * @param obj
 */
export const isPlainNumber = obj => typeof obj === 'number'

export default isPlainNumber
