import toTypeString from './toTypeString'

// 返回数据的类型 ex. string, number, boolean
export const toRawType = (obj:unknown) =>
  toTypeString(obj)
    .slice(8, -1)
    .toLocaleLowerCase()

export default toRawType
