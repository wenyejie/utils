/**
 * 判断数据是不是Boolean类型
 * @param obj
 */
export const isBoolean = obj => obj === true || obj === false

export default isBoolean
