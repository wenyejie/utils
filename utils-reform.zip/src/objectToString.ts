// Object.prototype.toString的封装, 主要用于提供性能
export const objectToString = Object.prototype.toString

export default objectToString