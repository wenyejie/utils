/**
 * 判断是否为字符串
 * @param obj
 */
export const isPlainString = (obj:any) => typeof obj === 'string'

export default isPlainString
