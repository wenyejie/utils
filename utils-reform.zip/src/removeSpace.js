import isString from './isString.ts'
const rSpace = /\s+/g

const removeSpace = string => {
  if (!isString(string)) {
    return ''
  }
  return string.replace(rSpace, '')
}

export default removeSpace
