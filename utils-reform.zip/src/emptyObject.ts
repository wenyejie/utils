// 被冻结的空对象
export const emptyObject = Object.freeze({})
export default emptyObject
