/**
 * 没有原型链的空对象
 */
export const nullProtoObject = () => Object.create(null)
export default nullProtoObject
