/**
 * 指向Object原型中hasOwnProperty方法
 */
export const hasOwnProperty = Object.prototype.hasOwnProperty
export default hasOwnProperty
