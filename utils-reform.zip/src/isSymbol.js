/**
 * 判断是否为symbol类型
 * @param obj
 */
export const isSymbol = obj => typeof obj === 'symbol'

export default isSymbol
