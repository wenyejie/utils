/**
 * 判断是否为函数
 * @param obj
 */
export const isFunction = obj => typeof obj === 'function'

export default isFunction
