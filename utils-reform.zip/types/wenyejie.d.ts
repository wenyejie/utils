type linkDateType = Date | string | number
